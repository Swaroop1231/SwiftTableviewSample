//
//  FruitsTableViewCell.swift
//  SwiftTableView
//
//  Created by User 0001 on 10/10/14.
//  Copyright (c) 2014 Colan Infotech. All rights reserved.
//

import UIKit

class FruitsTableViewCell: UITableViewCell
{
    @IBOutlet var fruitsNameLbl:UILabel?
    @IBOutlet var fruitsImgView:UIImageView?

    
    override func awakeFromNib()
    {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
