//
//  ViewController.swift
//  SwiftTableView
//
//  Created by User 0001 on 10/10/14.
//  Copyright (c) 2014 Colan Infotech. All rights reserved.
//

import UIKit


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
    {

    @IBOutlet var fruitsTableView: UITableView!
    
    let cellIdentifier = "cellIdentifier"
    var items = ["Apple", "Pear", "Banana", "Grapes", "Mango"]
    var itemImages=["apple.jpeg","pears.jpeg","banana.jpeg","grapes.jpeg","mango.jpeg"]
    let identifier = "cell"

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return self.items.count;
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat
    {
      return  75
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {

        var  cell:FruitsTableViewCell! = tableView.dequeueReusableCellWithIdentifier("customCell") as? FruitsTableViewCell
        
        if (cell == nil)
        {
            let nib:Array = NSBundle.mainBundle().loadNibNamed("FruitsTableViewCell", owner: self, options: nil)
            cell = nib[0] as? FruitsTableViewCell
        }
        
        cell.fruitsNameLbl?.text=self.items[indexPath.row]
        cell.fruitsImgView?.image=UIImage(named: self.itemImages[indexPath.row])
        
        return cell
}
    
    
    func tableView(tableView: UITableView!, didSelectRowAtIndexPath indexPath: NSIndexPath!)
    {
        //println("You selected cell #\(indexPath.row)!")
        
       let detailVC=DetailViewController(nibName:"DetailViewController", bundle: NSBundle .mainBundle())
        
        detailVC.detFruitsStr=self.items[indexPath.row]
        
        detailVC.detFruitsImgName=self.itemImages[indexPath.row]
   
        self.navigationController!.pushViewController(detailVC, animated: true)
        
      //  self.navigationController!.presentViewController(detailVC, animated: true, completion: nil)
        
    }

    
}

